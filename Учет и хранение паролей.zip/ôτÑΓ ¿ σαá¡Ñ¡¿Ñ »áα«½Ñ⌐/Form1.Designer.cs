﻿namespace Учет_и_хранение_паролей
{
	partial class Form1
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.loginTextBox = new System.Windows.Forms.TextBox();
			this.passwordTextBox = new System.Windows.Forms.TextBox();
			this.loginButton = new System.Windows.Forms.Button();
			this.createPasswordButton = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// loginTextBox
			// 
			this.loginTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.loginTextBox.Location = new System.Drawing.Point(107, 88);
			this.loginTextBox.Name = "loginTextBox";
			this.loginTextBox.Size = new System.Drawing.Size(207, 31);
			this.loginTextBox.TabIndex = 0;
			// 
			// passwordTextBox
			// 
			this.passwordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.passwordTextBox.Location = new System.Drawing.Point(107, 169);
			this.passwordTextBox.Name = "passwordTextBox";
			this.passwordTextBox.Size = new System.Drawing.Size(207, 31);
			this.passwordTextBox.TabIndex = 1;
			// 
			// loginButton
			// 
			this.loginButton.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.loginButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.loginButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.loginButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.loginButton.ForeColor = System.Drawing.Color.Transparent;
			this.loginButton.Location = new System.Drawing.Point(107, 206);
			this.loginButton.Name = "loginButton";
			this.loginButton.Size = new System.Drawing.Size(207, 60);
			this.loginButton.TabIndex = 2;
			this.loginButton.Text = "Войти в аккаунт";
			this.loginButton.UseVisualStyleBackColor = false;
			this.loginButton.Click += new System.EventHandler(this.loginButton_Click_1);
			// 
			// createPasswordButton
			// 
			this.createPasswordButton.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.createPasswordButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.createPasswordButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.createPasswordButton.ForeColor = System.Drawing.Color.Transparent;
			this.createPasswordButton.Location = new System.Drawing.Point(107, 282);
			this.createPasswordButton.Name = "createPasswordButton";
			this.createPasswordButton.Size = new System.Drawing.Size(207, 59);
			this.createPasswordButton.TabIndex = 3;
			this.createPasswordButton.Text = "Придумать надежный пароль";
			this.createPasswordButton.UseVisualStyleBackColor = false;
			this.createPasswordButton.Click += new System.EventHandler(this.createPasswordButton_Click_1);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label1.Location = new System.Drawing.Point(103, 61);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(193, 24);
			this.label1.TabIndex = 4;
			this.label1.Text = "Введите свой логин";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label2.Location = new System.Drawing.Point(103, 142);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(205, 24);
			this.label2.TabIndex = 5;
			this.label2.Text = "Введите свой пароль";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Montserrat SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label3.Location = new System.Drawing.Point(12, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(196, 29);
			this.label3.TabIndex = 6;
			this.label3.Text = "База данных №1";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(449, 372);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.createPasswordButton);
			this.Controls.Add(this.loginButton);
			this.Controls.Add(this.passwordTextBox);
			this.Controls.Add(this.loginTextBox);
			this.Name = "Form1";
			this.Text = "Авторизация";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox loginTextBox;
		private System.Windows.Forms.TextBox passwordTextBox;
		private System.Windows.Forms.Button loginButton;
		private System.Windows.Forms.Button createPasswordButton;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
	}
}

