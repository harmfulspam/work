﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Учет_и_хранение_паролей
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private string GenerateSecurePassword()
		{
			// Здесь можно реализовать логику для генерации надежного пароля
			// В данном примере генерируется случайная строка длиной 12 символов
			const string validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_-+=[]{}<>"; // Допустимые символы для пароля
			StringBuilder password = new StringBuilder();
			using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
			{
				byte[] uintBuffer = new byte[sizeof(uint)];
				int length = 12;
				while (length-- > 0)
				{
					rng.GetBytes(uintBuffer);
					uint num = BitConverter.ToUInt32(uintBuffer, 0);
					password.Append(validChars[(int)(num % (uint)validChars.Length)]);
				}
			}
			return password.ToString();
		}

		private string HashPassword(string password)
		{
			using (SHA256 sha256Hash = SHA256.Create())
			{
				byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));

				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < bytes.Length; i++)
				{
					builder.Append(bytes[i].ToString("x2"));
				}
				return builder.ToString();
			}
		}

		private void loginButton_Click_1(object sender, EventArgs e)
		{
			string enteredLogin = loginTextBox.Text;
			string enteredPassword = passwordTextBox.Text;

			// Предположим, проверка всегда успешна для примера
			bool loginSuccessful = true;
			string hashedPassword = HashPassword(enteredPassword);
			MessageBox.Show("Хэшированный пароль: " + hashedPassword);
			if (loginSuccessful)
			{
				// Переход на вторую форму после успешного входа
				Form2 databaseForm = new Form2();
				databaseForm.Show();
				this.Hide(); // Скрываем текущую форму
			}
			else
			{
				MessageBox.Show("Неверный логин или пароль. Попробуйте снова.");
				loginTextBox.Text = "";
				passwordTextBox.Text = "";
			}
		}

		private void createPasswordButton_Click_1(object sender, EventArgs e)
		{
			string generatedPassword = GenerateSecurePassword();
			passwordTextBox.Text = generatedPassword; // Вставка сгенерированного пароля в поле пароля
			MessageBox.Show("Создан новый надежный пароль и автоматически вставлен в поле.");
		}
	}
}



