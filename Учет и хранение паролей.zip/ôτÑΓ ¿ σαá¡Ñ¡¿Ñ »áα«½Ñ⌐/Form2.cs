﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Учет_и_хранение_паролей
{
	public partial class Form2 : Form
	{
		private DataTable databaseTable;

		public Form2()
		{
			InitializeComponent();
			//databaseTable = data;

			// Привязка таблицы к DataGridView на форме


			DataTable databaseTable = new DataTable();
			databaseTable.Columns.Add("Код", typeof(int));
			databaseTable.Columns.Add("Логин", typeof(string));
			databaseTable.Columns.Add("Пароль", typeof(string));
			databaseTable.Columns.Add("Сайт", typeof(string));

			// Добавляем строки с данными
			databaseTable.Rows.Add(1, "Maksik", "dffafac1", "Яндекс");
			databaseTable.Rows.Add(2, "Sashik", "qwert", "Фэйсбук");
			databaseTable.Rows.Add(3, "Ignat", "HNFAS111", "Gmail");
			databaseTable.Rows.Add(4, "pokest14", "hiUOU134!!!", "VK");
			databaseTable.Rows.Add(5, "hazbik", "156w1d41413", "Одноклассники");
			databaseTable.Rows.Add(6, "vladislav", "et,ezgfjrhg", "Ватсапп");
			// Устанавливаем эту таблицу в качестве источника данных для DataGridView
			dataGridView.DataSource = databaseTable;
		}

		private void Form2_Load(object sender, EventArgs e)
		{

		}

		private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void AddNewRowButton_Click(object sender, EventArgs e)
		{
			// Добавление новой записи в базу данных
			DataRow newRow = databaseTable.NewRow();
			newRow["ID"] = databaseTable.Rows.Count + 1;
			newRow["Login"] = "NewUser";
			newRow["Password"] = "NewPassword";
			newRow["Website"] = "NewWebsite.com";
			databaseTable.Rows.Add(newRow);
			MessageBox.Show("Новая запись добавлена.");
		}

		private void ExportButton_Click_1(object sender, EventArgs e)
		{
			SaveFileDialog saveDialog = new SaveFileDialog();
			saveDialog.Filter = "CSV файл (*.csv)|*.csv";
			saveDialog.Title = "Сохранить как CSV";

			if (saveDialog.ShowDialog() == DialogResult.OK)
			{
				DataTable table = (DataTable)dataGridView.DataSource;
				string delimiter = ",";

				// Создание строки заголовков
				string columnHeaderText = "";
				int countColumn = table.Columns.Count;
				for (int i = 0; i < countColumn; i++)
				{
					columnHeaderText += table.Columns[i].ColumnName + delimiter;
				}
				columnHeaderText = columnHeaderText.Remove(columnHeaderText.Length - 1);

				// Запись заголовков в файл
				System.IO.File.WriteAllText(saveDialog.FileName, columnHeaderText + Environment.NewLine);

				// Запись данных строк в файл
				foreach (DataRow row in table.Rows)
				{
					string rowData = "";
					for (int i = 0; i < countColumn; i++)
					{
						rowData += row[i].ToString() + delimiter;
					}
					rowData = rowData.Remove(rowData.Length - 1);
					System.IO.File.AppendAllText(saveDialog.FileName, rowData + Environment.NewLine);
				}

				MessageBox.Show("Данные успешно экспортированы в CSV файл.");
			}
		}

		private void SaveButton_Click_1(object sender, EventArgs e)
		{
			// Сохранение изменений в базе данных
			MessageBox.Show("Изменения сохранены.");
		}
	}
}
